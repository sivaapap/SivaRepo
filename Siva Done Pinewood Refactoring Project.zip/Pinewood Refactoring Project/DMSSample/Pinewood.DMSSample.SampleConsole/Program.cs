﻿// See https://aka.ms/new-console-template for more information
using Pinewood.DMSSample.Business;

DMSClient dmsClient = new DMSClient();

await dmsClient.CreatePartInvoiceAsync("1234", 10, "John Doe");
