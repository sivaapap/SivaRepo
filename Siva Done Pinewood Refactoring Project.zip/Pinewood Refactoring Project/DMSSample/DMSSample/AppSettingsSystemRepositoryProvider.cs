﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pinewood.DMSSample.Business
{
    public class AppSettingsSystemRepositoryProvider:IDMSRepositoryProvider
    {
        private ICustomerRepositoryDB customerRepository = null;
        private IPartInvoiceRepositoryDB partInvoiceRepository = null;
        private IPartAvailabilityService partAvailabilityService = null;
        public ICustomerRepositoryDB GetCustomerRepositoryDB()
        {
            ICustomerRepositoryDB customerRepository = null;

            try
            {
                string customerRepositoryClassInfo = ConfigurationManager.AppSettings["ICustomerRepositoryDB"];
                var customerRepoType = Type.GetType(customerRepositoryClassInfo);
                object customerRepoInstance = Activator.CreateInstance(customerRepoType);
                customerRepository = (ICustomerRepositoryDB)customerRepoInstance;
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to load ICustomerRepositoryDB implentation class. See inner exception for details.", ex);
            }

            if (customerRepository == null)
            {
                throw new Exception("Failed to load ICustomerRepositoryDB implentation class");
            }

            return customerRepository;
        }

        public IPartInvoiceRepositoryDB GetPartInvoiceRepositoryDB()
        {
            IPartInvoiceRepositoryDB partInvoiceRepository = null;
            try
            {
                string partInvoiceRepositoryClassInfo = ConfigurationManager.AppSettings["IPartInvoiceRepositoryDB"];
                var partRepoType = Type.GetType(partInvoiceRepositoryClassInfo);
                object partRepoInstance = Activator.CreateInstance(partRepoType);
                partInvoiceRepository = (IPartInvoiceRepositoryDB)partRepoInstance;

            }
            catch (Exception ex)
            {
                throw new Exception("Failed to load IPartInvoiceRepositoryDB implentation class. Please see inner exception for details.", ex);
            }

            if (partInvoiceRepository == null)
            {
                throw new Exception("Failed to load IPartInvoiceRepositoryDB implentation class");
            }

            return partInvoiceRepository;
        }

        public IPartAvailabilityService GetPartAvailabilityService()
        {
            IPartAvailabilityService partAvailabilityService = null;
            try
            {
                string partInvoiceRepositoryClassInfo = ConfigurationManager.AppSettings["IPartAvailabilityService"];
                var partRepoType = Type.GetType(partInvoiceRepositoryClassInfo);
                object partRepoInstance = Activator.CreateInstance(partRepoType);
                partAvailabilityService = (IPartAvailabilityService)partRepoInstance;

            }
            catch (Exception ex)
            {
                throw new Exception("Failed to load IPartAvailabilityService implentation class. Please see inner exception for details.", ex);
            }

            if (partAvailabilityService == null)
            {
                throw new Exception("Failed to load IPartAvailabilityService implentation class");
            }

            return partAvailabilityService;
        }

    }
}
