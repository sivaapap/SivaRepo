﻿namespace Pinewood.DMSSample.Business
{
    public interface IPartAvailabilityService:IDisposable
    {
        void Dispose();
        Task<int> GetAvailability(string stockCode);
    }
}