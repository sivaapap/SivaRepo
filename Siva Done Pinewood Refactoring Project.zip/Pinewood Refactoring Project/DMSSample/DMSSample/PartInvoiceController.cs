﻿namespace Pinewood.DMSSample.Business
{
    public class PartInvoiceController
    {
        public readonly ICustomerRepositoryDB _CustomerRepository;
        public readonly IPartInvoiceRepositoryDB _PartInvoiceRepository;
        public readonly IPartAvailabilityService _PartAvailabilityService;

        public PartInvoiceController(ICustomerRepositoryDB customerRepositoryDB, IPartInvoiceRepositoryDB partInvoiceRepositoryDB, IPartAvailabilityService partAvailabilityService)
        {
            if (customerRepositoryDB == null) throw new ArgumentException(nameof(customerRepositoryDB));
            if (partInvoiceRepositoryDB == null) throw new ArgumentException(nameof(partInvoiceRepositoryDB));
            if (partAvailabilityService == null) throw new ArgumentException(nameof(partAvailabilityService));

            _CustomerRepository = customerRepositoryDB;
            _PartInvoiceRepository = partInvoiceRepositoryDB;
            _PartAvailabilityService = partAvailabilityService;
        }

        public async Task<CreatePartInvoiceResult> CreatePartInvoiceAsync(string stockCode, int quantity, string customerName)
        {
            if (string.IsNullOrEmpty(stockCode))
            {
                return new CreatePartInvoiceResult(false);
            }

            if (quantity <= 0)
            {
                return new CreatePartInvoiceResult(false);
            }

            //CustomerRepositoryDBSQLServer _CustomerRepository = new CustomerRepositoryDBSQLServer();
            Customer? _Customer = _CustomerRepository.GetByName(customerName);
            int _CustomerID = _Customer?.ID ?? 0;
            if (_CustomerID <= 0)
            {
                return new CreatePartInvoiceResult(false);
            }

            //using (PartAvailabilityClient _PartAvailabilityService = new PartAvailabilityClient())
            using (_PartAvailabilityService)
            {
                int _Availability = await _PartAvailabilityService.GetAvailability(stockCode);
                if (_Availability <= 0)
                {
                    return new CreatePartInvoiceResult(false);
                }
            }

            PartInvoice _PartInvoice = new PartInvoice(
                stockCode: stockCode,
                quantity: quantity,
                customerID: _CustomerID
            );


            //PartInvoiceRepositoryDBSQLServer _PartInvoiceRepository = new PartInvoiceRepositoryDBSQLServer();
            _PartInvoiceRepository.Add(_PartInvoice);

            return new CreatePartInvoiceResult(true);
        }
    }
}
