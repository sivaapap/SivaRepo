﻿namespace Pinewood.DMSSample.Business
{
    public interface IPartInvoiceRepositoryDB
    {
        void Add(PartInvoice invoice);
    }
}