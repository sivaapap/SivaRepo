﻿using Pinewood.DMSSample.Business;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Pinewood.DMSSample.DataMock
{
    public class PartInvoiceRepositoryDBMock:IPartInvoiceRepositoryDB
    {
        private Dictionary<int, PartInvoice> _inoices=new Dictionary<int, PartInvoice>();

        public void Add(PartInvoice invoice)
        {
            if (invoice == null) throw new ArgumentNullException(nameof(invoice));

            lock(this)
            {
                if (_inoices.ContainsKey(invoice.ID))
                {
                    _inoices[invoice.ID] = invoice;
                }
                else
                {
                    _inoices.Add(invoice.ID, invoice);
                }
            }
        }
    }
}