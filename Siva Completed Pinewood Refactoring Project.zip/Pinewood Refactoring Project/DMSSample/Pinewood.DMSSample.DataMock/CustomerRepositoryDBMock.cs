﻿using Pinewood.DMSSample.Business;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Pinewood.DMSSample.DataMock
{
    public class CustomerRepositoryDBMock: ICustomerRepositoryDB
    {
        /*
             Create mock object as dictionary
        */
        private readonly Dictionary<string, Customer> _customerMap = new Dictionary<string, Customer>()
        {
            {"John Doe", new Customer(1234, "John Doe", "") },
            {"Samantha", new Customer(1235, "Samantha Jenkins", "") },


        };
        public Customer? GetByName(string name)
        {
            Customer? _Customer = null;
            if( _customerMap.ContainsKey(name))
            {
                _Customer = _customerMap[name];
            }
            return _Customer;
        }
    }
}