﻿using Pinewood.DMSSample.Business;

namespace Pinewood.DMSSample.MockService
{
    public class PartAvailabilityMockService : IPartAvailabilityService
    {
        private readonly Dictionary<string, int> _stockAvaliablity = new Dictionary<string, int>()
        {
            {"1234", 10 },{"1235",20}
        };
        public void Dispose()
        {

        }

        public Task<int> GetAvailability(string stockCode)
        {
            if (string.IsNullOrEmpty(stockCode))
                throw new ArgumentNullException("Stock code cannot be NULL");

            if (_stockAvaliablity.ContainsKey(stockCode))
                return Task.FromResult(_stockAvaliablity[stockCode]);


            return Task.FromResult(0);
        }
    }
}