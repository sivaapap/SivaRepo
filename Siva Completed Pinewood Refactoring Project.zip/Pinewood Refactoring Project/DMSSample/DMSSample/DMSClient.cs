﻿using System.Configuration;

namespace Pinewood.DMSSample.Business
{
    public class DMSClient
    {
        private PartInvoiceController __Controller;
        private IDMSRepositoryProvider _repositoryProvider;

        public DMSClient()
        {

            _repositoryProvider = new AppSettingsSystemRepositoryProvider();
            __Controller = new PartInvoiceController(_repositoryProvider.GetCustomerRepositoryDB(), _repositoryProvider.GetPartInvoiceRepositoryDB(), _repositoryProvider.GetPartAvailabilityService());
            
        }

        public async Task<CreatePartInvoiceResult> CreatePartInvoiceAsync(string stockCode, int quantity, string customerName)
        {
            return await __Controller.CreatePartInvoiceAsync(stockCode, quantity, customerName);
        }
    }
}