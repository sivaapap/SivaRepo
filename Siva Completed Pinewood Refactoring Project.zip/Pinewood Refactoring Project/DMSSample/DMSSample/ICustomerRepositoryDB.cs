﻿namespace Pinewood.DMSSample.Business
{
    public interface ICustomerRepositoryDB
    {
        Customer? GetByName(string name);
    }
}