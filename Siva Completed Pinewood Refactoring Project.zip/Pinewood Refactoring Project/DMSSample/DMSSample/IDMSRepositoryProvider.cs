﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pinewood.DMSSample.Business
{
    public interface IDMSRepositoryProvider
    {
        ICustomerRepositoryDB GetCustomerRepositoryDB();
        IPartInvoiceRepositoryDB GetPartInvoiceRepositoryDB();

        IPartAvailabilityService GetPartAvailabilityService();
    };
}
