﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pinewood.DMSSample.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pinewood.DMSSample.Business.Tests
{
    [TestClass()]
    public class PartInvoiceControllerTests
    {
        private PartInvoiceController _controller;
        private IDMSRepositoryProvider _repositoryProvider;
        [TestMethod()]
        public async Task CreatePartInvoiceAsyncPostiveTest()
        {
            try
            {
                _repositoryProvider = new AppSettingsSystemRepositoryProvider();
                _controller = new PartInvoiceController(_repositoryProvider.GetCustomerRepositoryDB(), _repositoryProvider.GetPartInvoiceRepositoryDB(), _repositoryProvider.GetPartAvailabilityService());

                var result = await _controller.CreatePartInvoiceAsync("1234", 10, "John Doe");
                Assert.IsTrue(result.Success);
            }
            catch (Exception ex)
            {
                Assert.Fail(String.Format("Exception while processing..{0}", ex.Message));
            }
        }

        [TestMethod]
        public async Task CreatePartInvoiceAsyncNegativeTest()
        {
            try
            {
                _repositoryProvider = new AppSettingsSystemRepositoryProvider();
                _controller = new PartInvoiceController(_repositoryProvider.GetCustomerRepositoryDB(), _repositoryProvider.GetPartInvoiceRepositoryDB(), _repositoryProvider.GetPartAvailabilityService());

                var result = await _controller.CreatePartInvoiceAsync("123", 10, "John Doe");
                Assert.IsFalse(result.Success);
            }
            catch (Exception ex)
            {
                Assert.Fail(String.Format("Exception while processing..{0}", ex.Message));
            }
        }
    }
}